#pragma once

typedef struct it{
    char simbolo;
    int chave;
}item;